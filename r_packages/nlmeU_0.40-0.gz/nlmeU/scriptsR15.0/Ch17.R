date()
packageVersion("nlmeU")
message("Code for Chapter 17 is distributed with nlmeForTesting package (Feb.15, 2013)")