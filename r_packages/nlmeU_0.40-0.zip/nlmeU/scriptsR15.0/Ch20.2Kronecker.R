date()
packageVersion("nlmeU")
message("Code for Section 20.2 is distributed with nlmeForTesting package (Feb.15, 2013)")